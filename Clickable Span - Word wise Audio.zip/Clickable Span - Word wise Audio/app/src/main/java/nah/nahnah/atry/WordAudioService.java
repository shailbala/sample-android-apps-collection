package nah.nahnah.atry;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;

import java.util.ArrayList;

import android.media.AudioManager;
import android.net.Uri;
import android.os.Binder;
import android.util.Log;

/**
 * The media playback is happening in this Service class, but the user interface comes from the Activity class
 */

public class WordAudioService extends Service implements
        MediaPlayer.OnPreparedListener, MediaPlayer.OnErrorListener,
        MediaPlayer.OnCompletionListener {

    private final IBinder audioBind = new AudioBinder();
    //media player
    private MediaPlayer player;
    //sentence
    private Sentence sentence;
    //current position
    private int wordPosn;

    public void onCreate() {
        //create the service
        super.onCreate();
        //initialize position
        wordPosn = 0;
        //create player
        player = new MediaPlayer();
        initMusicPlayer();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return audioBind;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        player.stop();
        player.release();
        return false;
    }

    public void initMusicPlayer() {
        //set player properties
        player.setAudioStreamType(AudioManager.STREAM_MUSIC);
        player.setOnPreparedListener(this);
        player.setOnCompletionListener(this);
        player.setOnErrorListener(this);
    }

    public void setSentence(Sentence sentence) {
        this.sentence = sentence;
    }

    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        mp.reset();
        return false;
    }

    @Override
    public void onPrepared(MediaPlayer mp) {
        //start playback
        mp.start();
    }
    public void setWord(int wordIndex){
        wordPosn = wordIndex;
    }

    public void playAudio() {
        //play a audio
        player.reset();
        long currWordId = sentence.getWordAudioi(wordPosn);
        //set uri
        /*
        Uri trackUri = ContentUris.withAppendedId(
                android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                currSong);
        */

        Uri trackUri = Uri.parse("android.resource://nah.nahnah.atry/" + currWordId);
        try {
            player.setDataSource(getApplicationContext(), trackUri);
        } catch (Exception e) {
            Log.e("MUSIC SERVICE", "Error setting data source", e);
        }
        //player.onCompletionListener is set in initMusicPlayer();
        player.setOnCompletionListener(this);
        player.prepareAsync();
    }

    //skip to next
    public void playNext() {
        wordPosn++;
        if (wordPosn >= sentence.getNumberOfWords()) wordPosn = 0;
        playAudio();
    }

    public void onCompletion(MediaPlayer mp) {
        if (player.getCurrentPosition() > 0) {
            mp.reset();
            playNext();
        }
    }

    public boolean isPlaying(){
        return player.isPlaying();
    }

    public class AudioBinder extends Binder {
        WordAudioService getService() {
            return WordAudioService.this;
        }
    }
}
