package nah.nahnah.atry;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.os.IBinder;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import nah.nahnah.atry.WordAudioService.AudioBinder;

public class MainActivity extends AppCompatActivity {

    private WordAudioService audioSrv;
    private Intent playIntent;
    private boolean audioBound=false;
    Sentence sentence;

    private boolean paused=false, playbackPaused=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        LinearLayout rootView = (LinearLayout) findViewById(R.id.song);

        sentence = new Sentence("mama naama shekharah");


        SpannableString ss = new SpannableString(sentence.getSentence());
        for(int i=0;i<sentence.getNumberOfWords();i++){
            //set clickableSpan for each word
            String word = sentence.getWordi(i);

        }
        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(View textView) {

            }

            //Makes the text underlined and in the link color.
            @Override
            public void updateDrawState(TextPaint ds) {
                super.updateDrawState(ds);
                ds.setUnderlineText(false);
            }
        };
        ss.setSpan(clickableSpan, 15, 20, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        Button nextButton = (Button) rootView.findViewById(R.id.nextButton);
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playNext();
            }
        });

        for(int i=0;i<sentence.getNumberOfWords();i++) {
            TextView word1 = new TextView(this);
            word1.setText(sentence.getWordi(i));
            word1.setClickable(true);
            word1.setTextColor(getResources().getColor(R.color.colorPrimary));
            word1.setOnClickListener(getWordClickListener(word1));
            rootView.addView(word1, param);
        }
    }

    @Override
    protected void onPause(){
        super.onPause();
        paused=true;
    }

    @Override
    protected void onDestroy() {
        stopService(playIntent);
        audioSrv=null;
        super.onDestroy();
    }

    public void doUnbindService() {
        if(audioBound) {
            stopService(playIntent);
            audioSrv = null;
            // Detach our existing connection.
            unbindService(audioConnection);
        }
    }

    public void doBindService() {
        if (playIntent == null) {
            playIntent = new Intent(this, WordAudioService.class);
            bindService(playIntent, audioConnection, Context.BIND_AUTO_CREATE);
            startService(playIntent);
            audioBound = true;
        }
    }

    @Override
    protected void onResume(){
        super.onResume();
        if(paused){
            paused=false;
        }
    }

    //connect to the service
    private ServiceConnection audioConnection = new ServiceConnection(){

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            AudioBinder binder = (AudioBinder)service;
            //get service
            audioSrv = binder.getService();
            //pass sentence
            audioSrv.setSentence(sentence);
            audioBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            audioBound = false;
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
        if(playIntent==null){
            playIntent = new Intent(this, WordAudioService.class);
            bindService(playIntent, audioConnection, Context.BIND_AUTO_CREATE);
            startService(playIntent);
        }
    }

    public View.OnClickListener getWordClickListener(final TextView textView){
        return new View.OnClickListener() {
            public void onClick(View v) {
                int pos = sentence.getWordPosition(textView.getText());
                if(pos != -1) {
                    audioSrv.setWord(pos);
                    audioSrv.playAudio();
                }
            }
        };
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //menu item selected
        switch (item.getItemId()) {
            case R.id.action_shuffle:
                //shuffle
                break;
            //end button, stop service and playback
            case R.id.action_end:
                stopService(playIntent);
                audioSrv=null;
                System.exit(0);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    //play next
    private void playNext() {
        audioSrv.playNext();
    }

    public boolean isPlaying(){
        if(audioSrv!=null && audioBound)
            return audioSrv.isPlaying();
        return false;
    }

    /**
     * Span spans everywhere
     * span spans here and there
     * span spans, wherever I see
     * Spans' span I want it to be!
     */
    /*
    * Custom ClickableSpan for
    * */
    public class myClickableSpan extends ClickableSpan {

        String word;
        int pos;
        public myClickableSpan(int position, String wordString){
            this.pos = position;
            this.word = wordString;
        }

        @Override
        public void onClick(View widget) {
            if(pos != -1) {
                audioSrv.setWord(pos);
                audioSrv.playAudio();
            }
        }
    }

}
