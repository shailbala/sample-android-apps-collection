package nah.nahnah.atry;


import java.util.ArrayList;

/*
* This class will take a sentence, break it into words, set audio id/path
* to each word and also implement a function called getWordPosition to return the position of the given word
*/
public class Sentence {
    private String mSentence;
    private String[] mWordlist;
    private ArrayList<Integer> mWordAudio;

    public Sentence(String sentence){
        mSentence = sentence;
        makeWords();
        attachAudio();
    }

    private void makeWords(){
        //called only from constructor to break the sentence into words
        mWordlist = mSentence.split(" ");
    }
    private void attachAudio(){
        //called only from constructor to attach audio path for words
        mWordAudio = new ArrayList<>();
        mWordAudio.add(R.raw.mama);
        mWordAudio.add(R.raw.naama);
        mWordAudio.add(R.raw.shekharah);
    }

    public int getWordPosition(String word){
        for(int i=0;i<mSentence.length();i++){
            if(mWordlist[i].contentEquals(word)){
                return i;
            }
        }
        return -1;
    }

    public int getWordPosition(CharSequence word){
        for(int i=0;i<mSentence.length();i++){
            if(mWordlist[i].contentEquals(word)){
                return i;
            }
        }
        return -1;
    }

    public int getNumberOfWords(){
        return mWordlist.length;
    }

    public String getWordi(int i){
        if(i>-1 && i<mWordlist.length){
            return mWordlist[i];
        }
        return "";
    }

    public int getWordAudioi(int i){
        if(i>-1 && i<mWordlist.length){
            return mWordAudio.get(i);
        }
        return -1;
    }

    public String getSentence(){return mSentence;}
}
